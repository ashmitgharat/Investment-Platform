<?php

namespace CoinGate\APIError;

# HTTP Status 400
class BadEnvironment extends BadRequest
{
}
